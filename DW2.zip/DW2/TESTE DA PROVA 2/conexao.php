<?php
class Conexao {
    private $servername;
    private $username;
    private $password;
    private $dbname;
    private $conn;

    public function __construct() {
        $this->servername = '127.0.0.1'; // altere para o seu servidor MySQL
        $this->username = 'Teste'; // altere para o seu nome de usuário do MySQL
        $this->password = 'sua_senha_aqui'; // adicione sua senha do MySQL aqui
        $this->dbname = 'teste'; // altere para o nome do seu banco de dados
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);

        if ($this->conn->connect_error) {
            die("Conexão falhou: " . $this->conn->connect_error);
        }
    }

    public function cadastrarCandidato($nome, $documento, $telefone, $escolaPublica) {
        $sql = "INSERT INTO candidatos (nome, documento, telefone, escola_publica) VALUES ('$nome', '$documento', '$telefone', '$escolaPublica')";

        if ($this->conn->query($sql) === TRUE) {
            echo "Novo registro criado com sucesso.";
        } else {
            echo "Erro: " . $sql . "<br>" . $this->conn->error;
        }
    }

    // Outros métodos para ler, atualizar e excluir candidatos
    // Implemente conforme as necessidades do seu aplicativo

    public function fecharConexao() {
        $this->conn->close();
    }
}

// Exemplo de uso da classe Conexao
$conexao = new Conexao();
$conexao->cadastrarCandidato("Gerson", "884754755", "995547452", "1");
$conexao->fecharConexao();
?>